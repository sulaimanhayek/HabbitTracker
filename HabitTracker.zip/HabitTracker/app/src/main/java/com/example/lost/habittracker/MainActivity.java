package com.example.lost.habittracker;

import android.content.ContentValues;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Get an instance of the HabitsDBHelper (this creates or upgrades the database if needed)
        HabitsDBHelper habitsDBHelper = new HabitsDBHelper(this);
        // Create a new record
        ContentValues contentValues = new ContentValues();
        contentValues.put(HabitsContract.HabitsEntry.habitName, "Reading Books");
        contentValues.put(HabitsContract.HabitsEntry.habitDateAdded, "11/1/2017");
        contentValues.put(HabitsContract.HabitsEntry.habitCount, 0);
        habitsDBHelper.insertRecord(contentValues);
        // Update the record
        contentValues.put(HabitsContract.HabitsEntry.habitDateLastDone, "11/4/2017");
        contentValues.put(HabitsContract.HabitsEntry.habitCount, 1);
        habitsDBHelper.updateRecord(1, contentValues);
        // Get the record
        Cursor habitRecord = habitsDBHelper.getRecord(1);
        Log.i("getRecord ", habitRecord.toString());
    }
}

