package com.example.lost.habittracker;

import android.provider.BaseColumns;

/**
 * Created by lost on 04/11/2017.
 */

class HabitsContract {
    public static final class HabitsEntry implements BaseColumns {
        // The internal id is used by all tables
        public static final String HABITS_TABLE_NAME = "habits";
        //The habits table fields
        public static final String habitId = "row_id";
        public static final String habitName = "name";
        public static final String habitCount = "count";
        public static final String habitDateAdded = "date_added";
        public static final String habitDateLastDone = "date_last_done";
    }
}

